-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         8.0.30 - MySQL Community Server - GPL
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para mirutina
CREATE DATABASE IF NOT EXISTS `mirutina` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mirutina`;

-- Volcando estructura para procedimiento mirutina.ActualizarEjercicio
DELIMITER //
CREATE PROCEDURE `ActualizarEjercicio`(IN _ID INT,IN _nombre VARCHAR(255),IN _recomendacion TEXT)
BEGIN
    UPDATE ejercicios SET nombre=_nombre, recomendacion=_recomendacion WHERE id=_ID;
    
END//
DELIMITER ;

-- Volcando estructura para procedimiento mirutina.CrearEjercicio
DELIMITER //
CREATE PROCEDURE `CrearEjercicio`(IN _nombre VARCHAR(255), IN _recomendacion TEXT)
BEGIN
    INSERT INTO ejercicios(nombre, recomendacion) VALUES (_nombre, _recomendacion);
END//
DELIMITER ;

-- Volcando estructura para tabla mirutina.dias
CREATE TABLE IF NOT EXISTS `dias` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre_dia` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parte_cuerpo_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dias_parte_cuerpo_id_foreign` (`parte_cuerpo_id`),
  CONSTRAINT `dias_parte_cuerpo_id_foreign` FOREIGN KEY (`parte_cuerpo_id`) REFERENCES `partes_del_cuerpo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla mirutina.dias: ~2 rows (aproximadamente)
INSERT INTO `dias` (`id`, `nombre_dia`, `parte_cuerpo_id`, `created_at`, `updated_at`) VALUES
	(1, 'Lunes', 3, NULL, NULL),
	(2, 'Martes', 1, '2024-04-08 16:19:59', '2024-04-08 16:20:00');

-- Volcando estructura para procedimiento mirutina.EditarEjercicio
DELIMITER //
CREATE PROCEDURE `EditarEjercicio`(IN ejercicioID INT)
BEGIN
    SELECT * FROM ejercicios
    WHERE id = ejercicioID;
END//
DELIMITER ;

-- Volcando estructura para tabla mirutina.ejercicios
CREATE TABLE IF NOT EXISTS `ejercicios` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recomendacion` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla mirutina.ejercicios: ~8 rows (aproximadamente)
INSERT INTO `ejercicios` (`id`, `nombre`, `recomendacion`, `created_at`, `updated_at`) VALUES
	(1, 'sentadilla', 'libre o en smith', '2024-04-05 20:12:43', '2024-04-05 20:12:44'),
	(2, 'sentadilla sumo', 'enfocada en glúteos', '2024-04-05 20:13:05', '2024-04-05 20:13:05'),
	(3, 'peso muerto', 'Libre o en smith o barra', '2024-04-05 20:13:22', '2024-04-05 20:13:23'),
	(4, 'extensiones', 'método piramidal ascendente', '2024-04-05 20:13:52', '2024-04-05 20:13:52'),
	(5, 'Curl de biceps', 'Con mancuernas', NULL, NULL),
	(6, 'Dominada', 'Asistidas en máquina o liga de resistencia', NULL, NULL),
	(12, 'hacka', 'Método piramidal', NULL, NULL),
	(16, 'facepull', 'Utilizar polea', NULL, NULL);

-- Volcando estructura para procedimiento mirutina.EliminarEjercicio
DELIMITER //
CREATE PROCEDURE `EliminarEjercicio`(IN idEjercicio INT)
BEGIN
    
    DELETE FROM ejercicios WHERE id = idEjercicio; 
END//
DELIMITER ;

-- Volcando estructura para tabla mirutina.failed_jobs
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla mirutina.failed_jobs: ~0 rows (aproximadamente)

-- Volcando estructura para procedimiento mirutina.GetEjercicio
DELIMITER //
CREATE PROCEDURE `GetEjercicio`()
BEGIN
    SELECT * FROM ejercicios;
END//
DELIMITER ;

-- Volcando estructura para tabla mirutina.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla mirutina.migrations: ~0 rows (aproximadamente)
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_000000_create_users_table', 1),
	(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
	(3, '2019_08_19_000000_create_failed_jobs_table', 1),
	(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
	(5, '2024_04_05_033040_create_rutinas_table', 1),
	(6, '2024_04_05_033851_create_partes_del_cuerpo_table', 1),
	(7, '2024_04_05_033942_create_dias_table', 1),
	(8, '2024_04_05_034453_create_ejercicios_table', 1),
	(9, '2024_04_05_034848_create_rutina_ejercicios_table', 1),
	(10, '2024_04_08_044759_modify_nombre_tabla_table', 2),
	(11, '2024_04_08_044843_modify_rutina_ejercicios_table', 2),
	(12, '2024_04_08_045213_drop_rutinas_table', 3),
	(13, '2024_04_08_045941_modify_rutina_ejercicios_table', 4),
	(14, '2024_04_08_050121_modify_rutina_ejercicios_table', 5);

-- Volcando estructura para tabla mirutina.partes_del_cuerpo
CREATE TABLE IF NOT EXISTS `partes_del_cuerpo` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla mirutina.partes_del_cuerpo: ~3 rows (aproximadamente)
INSERT INTO `partes_del_cuerpo` (`id`, `nombre`, `created_at`, `updated_at`) VALUES
	(1, 'Superior', '2024-04-08 04:56:08', '2024-04-08 04:56:09'),
	(2, 'Inferior', '2024-04-08 04:56:24', '2024-04-08 04:56:25'),
	(3, 'Cuerpo completo', '2024-04-08 04:56:38', '2024-04-08 04:56:39');

-- Volcando estructura para tabla mirutina.password_reset_tokens
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla mirutina.password_reset_tokens: ~0 rows (aproximadamente)

-- Volcando estructura para tabla mirutina.personal_access_tokens
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla mirutina.personal_access_tokens: ~0 rows (aproximadamente)

-- Volcando estructura para tabla mirutina.rutina_ejercicios
CREATE TABLE IF NOT EXISTS `rutina_ejercicios` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `dia_id` bigint unsigned NOT NULL,
  `ejercicio_id` bigint unsigned NOT NULL,
  `peso` int NOT NULL,
  `repeticiones` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rutina_ejercicios_dia_id_foreign` (`dia_id`),
  KEY `rutina_ejercicios_ejercicio_id_foreign` (`ejercicio_id`),
  CONSTRAINT `rutina_ejercicios_dia_id_foreign` FOREIGN KEY (`dia_id`) REFERENCES `dias` (`id`),
  CONSTRAINT `rutina_ejercicios_ejercicio_id_foreign` FOREIGN KEY (`ejercicio_id`) REFERENCES `ejercicios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla mirutina.rutina_ejercicios: ~2 rows (aproximadamente)
INSERT INTO `rutina_ejercicios` (`id`, `dia_id`, `ejercicio_id`, `peso`, `repeticiones`, `created_at`, `updated_at`) VALUES
	(1, 1, 5, 15, 10, '2024-04-08 16:19:03', '2024-04-08 16:19:05'),
	(2, 2, 4, 145, 12, '2024-04-08 16:20:44', '2024-04-08 16:20:45');

-- Volcando estructura para tabla mirutina.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla mirutina.users: ~0 rows (aproximadamente)

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
